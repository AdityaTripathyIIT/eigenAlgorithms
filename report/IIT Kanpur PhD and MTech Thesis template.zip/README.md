(CC BY-NC-SA 3.0)


This second major version of this template was made by Vel. The thesis style was originally created by Steve R. Gunn and modified into a template by Sunil Patel.

Downloaded from latextemplates.com

Modified for IITK Thesis requirements.
